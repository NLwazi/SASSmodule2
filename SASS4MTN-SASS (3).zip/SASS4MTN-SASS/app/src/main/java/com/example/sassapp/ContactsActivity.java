package com.example.sassapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.example.sassapp.model.contact;
import com.example.sassapp.store.contactstore;

import java.util.ArrayList;
import java.util.List;

public class ContactsActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    contactstore contactStore;
    private View main;
    private ImageView imageView;

    int[] images = {R.drawable.profileone,R.drawable.profiletwo,R.drawable.profilethree,R.drawable.profilefour,R.drawable.profilefive,R.drawable.profilesix};
    String[] names = {"Ndumiso","Sbali","Mohammed","Malume","Braid","Sean"};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contacts);


        List<contact> contactsData = new ArrayList<>();
        contactsData.add(new contact(names[0],images[0]));
        contactsData.add(new contact(names[1],images[1]));
        contactsData.add(new contact(names[2],images[2]));
        contactsData.add(new contact(names[3],images[3]));
        contactsData.add(new contact(names[4],images[4]));
        contactsData.add(new contact(names[5],images[5]));

        getContact(contactsData);

    }




    private void getContact(List<contact> list){
        recyclerView = findViewById(R.id.contactlistview);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this,RecyclerView.VERTICAL,false);

        recyclerView.setLayoutManager(layoutManager);
        contactStore = new contactstore(this,list);
        recyclerView.setAdapter(contactStore);


    }



}