package com.example.sassapp.store;

import android.content.Context;
import android.content.Intent;
import android.net.sip.SipSession;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.sassapp.ProfileActivity;
import com.example.sassapp.R;
import com.example.sassapp.model.contact;

import java.util.List;

public class contactstore extends RecyclerView.Adapter<contactstore.ContactViewHolder> {


    Context context;
    List<contact> contact_list;

    private ContactViewClicklListner lister;



    public contactstore(Context context, List<contact> contact_list) {
        this.context = context;
        this.contact_list = contact_list;
    }

    @NonNull
    @Override
    public ContactViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.contact_temp,parent,false);
        return new ContactViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ContactViewHolder holder, int position) {

        holder.storeimage.setImageResource(contact_list.get(position).getImage());
        holder.textView.setText(contact_list.get(position).getName());
        holder.linearlayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(context, ProfileActivity.class);
                intent.putExtra("logo",contact_list.get(position).getImage());
                intent.putExtra("name",contact_list.get(position).getName());
                context.startActivity(intent);

            }
        });

    }

    @Override
    public int getItemCount() {
        return contact_list.size();
    }


    public static final class ContactViewHolder extends RecyclerView.ViewHolder {

        ImageView storeimage;
        TextView textView;
        LinearLayout linearlayout;


        public ContactViewHolder(@NonNull View itemView) {

            super(itemView);

            storeimage = itemView.findViewById(R.id.profile_temp);
            textView = itemView.findViewById(R.id.name_temp);

            linearlayout = itemView.findViewById(R.id.linearLayout);

        }


    }



    public interface ContactViewClicklListner{
        void onClick(View view, int position);
    }



}

