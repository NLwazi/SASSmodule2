package com.example.sassapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class HomeActivityONE extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_o_n_e);
    }
}