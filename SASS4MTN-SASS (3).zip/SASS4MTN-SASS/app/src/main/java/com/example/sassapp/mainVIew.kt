package com.example.sassapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class mainVIew : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_v_iew)
    }
}